[Transient Analysis]
{
   Npanes: 1
   {
      traces: 2 {524290,0,"V(vosandn)"} {524291,0,"V(vin)"}
      X: ('�',1,0,1e-007,1.49999e-006)
      Y[0]: (' ',1,0,0.1,1)
      Y[1]: ('_',0,1e+308,0,-1e+308)
      Volts: (' ',0,0,1,0,0.1,1)
      Log: 0 0 0
      GridStyle: 1
   }
}
