Version 4
SymbolType BLOCK
LINE Normal 0 -80 -16 -80
LINE Normal 224 -160 224 -176
LINE Normal 304 -80 320 -80
LINE Normal 144 0 144 16
LINE Normal 80 -160 80 -176
RECTANGLE Normal 304 -160 0 0
TEXT 7 -80 Left 2 Vin
TEXT 248 -81 Left 2 Vout
TEXT 109 -15 Left 2 Clock
TEXT 202 -145 Left 2 VDD
TEXT 57 -145 Left 2 VCM
TEXT 41 -115 Left 2 2nd-order NS Active
TEXT 96 -85 Left 2 Modulator
TEXT 83 -53 Left 2 R=2k C=10pF
PIN -16 -80 NONE 8
PINATTR PinName Vin
PINATTR SpiceOrder 1
PIN 224 -176 NONE 8
PINATTR PinName VDD
PINATTR SpiceOrder 2
PIN 320 -80 NONE 8
PINATTR PinName Vout
PINATTR SpiceOrder 3
PIN 144 16 NONE 8
PINATTR PinName Clock
PINATTR SpiceOrder 4
PIN 80 -176 NONE 8
PINATTR PinName VCM
PINATTR SpiceOrder 5
