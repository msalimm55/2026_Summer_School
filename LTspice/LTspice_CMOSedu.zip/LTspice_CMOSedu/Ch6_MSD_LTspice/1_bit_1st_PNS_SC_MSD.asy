Version 4
SymbolType BLOCK
LINE Normal 0 -80 -16 -80
LINE Normal 224 -160 224 -176
LINE Normal 304 -80 320 -80
LINE Normal 96 0 96 16
LINE Normal 80 -160 80 -176
LINE Normal 224 0 224 16
RECTANGLE Normal 304 -160 0 0
TEXT 7 -80 Left 2 Vin
TEXT 248 -81 Left 2 Vout
TEXT 73 -14 Left 2 Phi1
TEXT 202 -145 Left 2 VDD
TEXT 57 -145 Left 2 VCM
TEXT 13 -116 Left 2 1st-order SC NS Passive
TEXT 96 -85 Left 2 Modulator
TEXT 44 -50 Left 2 Ci,f=1pF Cint=10pF
TEXT 200 -14 Left 2 Phi2
PIN -16 -80 NONE 8
PINATTR PinName Vin
PINATTR SpiceOrder 1
PIN 224 -176 NONE 8
PINATTR PinName VDD
PINATTR SpiceOrder 2
PIN 320 -80 NONE 8
PINATTR PinName Vout
PINATTR SpiceOrder 3
PIN 96 16 NONE 8
PINATTR PinName phi1
PINATTR SpiceOrder 4
PIN 80 -176 NONE 8
PINATTR PinName VCM
PINATTR SpiceOrder 5
PIN 224 16 NONE 8
PINATTR PinName phi2
PINATTR SpiceOrder 6
